import 'package:b6030202472/config/net/base_api.dart';
import 'package:b6030202472/model/song_model.dart';

class BaseRepository {
  /// รับรายการเพลง
  static Future fetchSongList(String input, int page) async {
    var response = await http.post('/', data: {
      'input': input,
      'type': 'netease',
      'page': page,
      'filter': 'name',
    });
    return response.data
        .map<Song>((item) => Song.fromJsonMap(item))
        .toList();
  }
}
