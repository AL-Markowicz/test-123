
/// ประเภทสถานะ
enum ViewState {
  idle,
  busy,
  empty,
  error,
  unAuthorized,
}

/// ประเภทข้อผิดพลาด
enum ErrorType {
  defaultError,
  networkError,
}

class ViewStateError {
  ErrorType errorType;
  String message;
  String errorMessage;

  ViewStateError(this.errorType, {this.message, this.errorMessage}) {
    errorType ??= ErrorType.defaultError;
    message ??= errorMessage;
  }

  /// มีการเพิ่มตัวแปรต่อไปนี้เพื่อความสะดวกในการเขียนโค้ด *-*
  get isNetworkError => errorType == ErrorType.networkError;

  @override
  String toString() {
    return 'ViewStateError{errorType: $errorType, message: $message, errorMessage: $errorMessage}';
  }
}


