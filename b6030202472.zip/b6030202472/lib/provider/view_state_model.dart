import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:b6030202472/config/net/api.dart';
import 'package:b6030202472/generated/i18n.dart';
import 'package:oktoast/oktoast.dart';

import 'view_state.dart';

class ViewStateModel with ChangeNotifier {
  /// ป้องกันการทำงานแบบอะซิงโครนัสไม่ให้เสร็จสิ้น
  bool _disposed = false;

  /// สถานะหน้าปัจจุบันค่าเริ่มต้นไม่ว่างซึ่งสามารถระบุได้ในตัวสร้างของ viewModel;
  ViewState _viewState;

  /// คลาสย่อยสามารถระบุสถานะหน้าที่ต้องการในตัวสร้าง
  /// FooModel (): super (viewState: ViewState.busy);
  ViewStateModel({ViewState viewState})
      : _viewState = viewState ?? ViewState.idle {
    //debugPrint('ViewStateModel---constructor--->$runtimeType');
  }

  ViewState get viewState => _viewState;

  set viewState(ViewState viewState) {
    _viewStateError = null;
    _viewState = viewState;
    notifyListeners();
  }

  ViewStateError _viewStateError;

  ViewStateError get viewStateError => _viewStateError;

  String get errorMessage => _viewStateError?.message;

  /// มีการเพิ่มตัวแปรต่อไปนี้เพื่อความสะดวกในการเขียนโค้ด *-*

  bool get busy => viewState == ViewState.busy;

  bool get idle => viewState == ViewState.idle;

  bool get empty => viewState == ViewState.empty;

  bool get error => viewState == ViewState.error;

  bool get unAuthorized => viewState == ViewState.unAuthorized;

  void setIdle() {
    viewState = ViewState.idle;
  }

  void setBusy() {
    viewState = ViewState.busy;
  }

  void setEmpty() {
    viewState = ViewState.empty;
  }

  void setUnAuthorized() {
    viewState = ViewState.unAuthorized;
    onUnAuthorizedException();
  }


  void onUnAuthorizedException() {}

  /// [e] จำแนกข้อผิดพลาดและข้อยกเว้น
  void setError(e, stackTrace, {String message}) {
    ErrorType errorType = ErrorType.defaultError;
    if (e is DioError) {
      e = e.error;
      if (e is UnAuthorizedException) {
        stackTrace = null;

        /// ได้รับการจัดการใน onAuthorizedException
        setUnAuthorized();
        return;
      } else if (e is NotSuccessException) {
        stackTrace = null;
        message = e.error;
      } else {
        errorType = ErrorType.networkError;
      }
    }
    viewState = ViewState.error;
    _viewStateError = ViewStateError(
      errorType,
      message: message,
      errorMessage: e.toString(),
    );
    printErrorStack(e, stackTrace);
  }

  /// แสดงข้อความผิดพลาด
  showErrorMessage(context, {String message}) {
    if (viewStateError != null || message != null) {
      if (viewStateError.isNetworkError) {
        message ??= S.of(context).viewStateMessageNetworkError;
      } else {
        message ??= viewStateError.message;
      }
      Future.microtask(() {
        showToast(message, context: context);
      });
    }
  }

  @override
  String toString() {
    return 'BaseModel{_viewState: $viewState, _viewStateError: $_viewStateError}';
  }

  @override
  void notifyListeners() {
    if (!_disposed) {
      super.notifyListeners();
    }
  }

  @override
  void dispose() {
    _disposed = true;
    debugPrint('view_state_model dispose -->$runtimeType');
    super.dispose();
  }
}

/// [e] เป็นประเภทข้อผิดพลาด: อาจเป็นข้อผิดพลาดข้อยกเว้นสตริง
/// [s] เป็นข้อมูลสแต็ก
printErrorStack(e, s) {
  debugPrint('''
<-----↓↓↓↓↓↓↓↓↓↓-----error-----↓↓↓↓↓↓↓↓↓↓----->
$e
<-----↑↑↑↑↑↑↑↑↑↑-----error-----↑↑↑↑↑↑↑↑↑↑----->''');
  if (s != null) debugPrint('''
<-----↓↓↓↓↓↓↓↓↓↓-----trace-----↓↓↓↓↓↓↓↓↓↓----->
$s
<-----↑↑↑↑↑↑↑↑↑↑-----trace-----↑↑↑↑↑↑↑↑↑↑----->''');
}
