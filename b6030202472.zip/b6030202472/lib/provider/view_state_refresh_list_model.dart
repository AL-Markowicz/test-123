import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';

import 'view_state_list_model.dart';


abstract class ViewStateRefreshListModel<T> extends ViewStateListModel<T> {
  /// การแบ่งหน้าหมายเลขหน้าแรก
  static const int pageNumFirst = 1;


  static const int pageSize = 10;

  RefreshController _refreshController =
      RefreshController(initialRefresh: false);

  RefreshController get refreshController => _refreshController;

  /// หมายเลขหน้าปัจจุบัน
  int _currentPageNum = pageNumFirst;

  /// ดึงลงเพื่อรีเฟรช
  ///
  /// [init] ไม่ว่าจะเป็นการโหลดครั้งแรกหรือไม่
  /// true: เมื่อเกิดข้อผิดพลาดคุณต้องข้าม
  /// false: ข้อผิดพลาดไม่จำเป็นต้องข้าม
  Future<List<T>> refresh({bool init = false}) async {
    try {
      _currentPageNum = pageNumFirst;
      var data = await loadData(pageNum: pageNumFirst);
      if (data.isEmpty) {
        refreshController.refreshCompleted(resetFooterState: true);
        list.clear();
        setEmpty();
      } else {
        onCompleted(data);
        list.clear();
        list.addAll(data);
        refreshController.refreshCompleted();

        if (data.length < pageSize) {
          refreshController.loadNoData();
        } else {

          refreshController.loadComplete();
        }
        setIdle();
      }
      return data;
    } catch (e, s) {
      /// หน้าถูกโหลดด้วยข้อมูลหากรายงานข้อผิดพลาดในการรีเฟรชคุณไม่ควรข้ามไปยังหน้าข้อผิดพลาดโดยตรง
      if (init) list.clear();
      refreshController.refreshFailed();
      setError(e, s);
      return null;
    }
  }

  /// ดึงขึ้นเพื่อโหลดมากขึ้น
  Future<List<T>> loadMore() async {
    try {
      var data = await loadData(pageNum: ++_currentPageNum);
      if (data.isEmpty) {
        _currentPageNum--;
        refreshController.loadNoData();
      } else {
        onCompleted(data);
        list.addAll(data);
        if (data.length < pageSize) {
          refreshController.loadNoData();
        } else {
          refreshController.loadComplete();
        }
        notifyListeners();
      }
      return data;
    } catch (e, s) {
      _currentPageNum--;
      refreshController.loadFailed();
      debugPrint('error--->\n' + e.toString());
      debugPrint('statck--->\n' + s.toString());
      return null;
    }
  }

  // โหลดข้อมูล
  Future<List<T>> loadData({int pageNum});

  @override
  void dispose() {
    _refreshController.dispose();
    super.dispose();
  }
}
