import 'dart:io';

import 'package:localstorage/localstorage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:path_provider/path_provider.dart';

class StorageManager {
  /// การกำหนดค่าของแอป เช่น:theme
  static SharedPreferences sharedPreferences;

  /// ไดเรกทอรีชั่วคราว เช่น: cookie
  static Directory temporaryDirectory;


  /// ต้องการการดำเนินการเบื้องต้น เช่น: ข้อมูลผู้ใช้
  static LocalStorage localStorage;

  static init() async {

    temporaryDirectory = await getTemporaryDirectory();
    sharedPreferences = await SharedPreferences.getInstance();
    localStorage = LocalStorage('LocalStorage');
    await localStorage.ready;
  }
}
