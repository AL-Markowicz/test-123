import 'dart:convert';
import 'package:dio/native_imp.dart';
import 'package:flutter/foundation.dart';
import 'package:dio/dio.dart';



_parseAndDecode(String response) {
  return jsonDecode(response);
}

parseJson(String text) {
  return compute(_parseAndDecode, text);
}

abstract class BaseHttp extends DioForNative {
  BaseHttp() {

    (transformer as DefaultTransformer).jsonDecodeCallback = parseJson;

    interceptors..add(HeaderInterceptor());
    init();
  }

  void init();
}

/// Header
class HeaderInterceptor extends InterceptorsWrapper {
  @override
  onRequest(RequestOptions options) async {
    options.connectTimeout = 1000 * 45;
    options.receiveTimeout = 1000 * 45;
    options.contentType = 'application/x-www-form-urlencoded; charset=UTF-8';


    options.headers['X-Requested-With'] = 'XMLHttpRequest';
    return options;
  }
}

/// คลาสย่อย
abstract class BaseResponseData {
  int code = 0;
  String error;
  dynamic data;

  bool get success;

  BaseResponseData({this.code, this.error, this.data});

  @override
  String toString() {
    return 'BaseRespData{code: $code, message: $error, data: $data}';
  }
}

/// รหัสอินเทอร์เฟซ
class NotSuccessException implements Exception {
  String error;

  NotSuccessException.fromRespData(BaseResponseData respData) {
    error = respData.error;
  }

  @override
  String toString() {
    return 'NotExpectedException{respData: $error}';
  }
}

/// การอนุญาตไม่เพียงพอสำหรับการไม่ลงชื่อเข้าใช้ ฯลฯ คุณต้องข้ามไปที่หน้าการให้สิทธิ์
class UnAuthorizedException implements Exception {
  const UnAuthorizedException();

  @override
  String toString() => 'UnAuthorizedException';
}